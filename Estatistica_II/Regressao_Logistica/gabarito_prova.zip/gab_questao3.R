#Quest�o 3

df <- read.table("questao3.txt", header = TRUE)

#or

#df <- read.csv('questao3.csv', sep = ',', dec = '.')

#print df 
df


#a) Ajuste do modelo de regress�o log��stica bin�ria da vari�vel sa�de em fun��o de idade e renda.


#a.1) 

logit<- glm(saude ~ idade + renda, data=df, family = binomial(link="logit"))
summary(logit)


#a.2) 
logit <- glm(saude ~ idade + renda, data = df, family = "binomial")
summary(logit)
print(logit)

df$probability <- predict(logit, df, type = "response")

df$saude_pred <- ifelse(df$probability > 0.5, 1, 0)


df$saude_pred <- as.factor(df$saude_pred)
df$saude <- as.factor(df$saude)

cm <- confusionMatrix(df$saude_pred, df$saude)
print(cm$table)

accuracy <- mean(df$saude_pred == df$saude)  #acurracy of model 
print(accuracy)

cm$table


#matriz de confusão utilizando table (frequencia)
confusion_matrix <- as.data.frame(table(df$saude_pred, df$saude))

ggplot(data = confusion_matrix, mapping = aes(x = Var1, y = Var2)) +
  geom_tile(aes(fill = Freq)) +
  geom_text(aes(label = sprintf("%1.0f", Freq)), vjust = 1) +
  scale_fill_gradient(low = "blue",
                      high = "red") # 


#b) Interprete os valores do logit e da raz�o de chances.

#Interpreta��o do logit: 
#b1: a cada unidade adicional na vari�vel idade, espera-se que o logaritmo das chances a favor (sa�de n�o boa) aumente em 0.1329 unidades.
#b2: a cada unidade adicional na vari�vel renda (at� 3 sal�rios m�nimos), espera-se que o logaritmo das chances a favor (sa�de n�o boa) diminua em 3.1789 unidades.


Interpreta��o da raz�o de chances: devemos tomar o antilogaritmo do logit estimado. 
#b1: Para uma unidade de aumento da vari�vel idade, as chances favor�veis a Y=1 (sa�de n�o boa) aumentam  cerca de e^0.13 unidades.
#b1: Para uma unidade de aumento da vari�vel renda, as chances favor�veis a Y=1 (sa�de n�o boa) diminuem  cerca de e^3.18 unidades.


#Interpreta��o Geral: Tanto a idade quanto a renda familiar per capita est�o significativamente relacionadas com a chance de autoavalia��o de sa�de n�o boa 
#(OBS: Note que o p-valor � menor que o n�vel de signific�ncia de 5% e o IC para OR n�o inclui a unidade).

#A chance do indiv�duo reportar um estado de sa�de n�o bom aumenta em 14,2% ao aumentar em 1 ano a idade.
#Indiv�duos com mais de 3 sal�rios m�nimos tem uma chance de reportar um estado de sa�de n�o bom 95,8% menor do que os indiv�duos que ganham no m�ximo 3 sal�rios m�nimos.

