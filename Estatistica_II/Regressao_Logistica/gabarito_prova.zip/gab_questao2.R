#Quest�o 2

df <- read.table("questao2.txt", header = TRUE)

#or

#df <- read.csv('questao2.csv', sep = ',', dec = '.')

#print df 
df



#a) Fa�a o gr�fico de dispers�o.

grafico<-plot(df)
grafico


#or 

ggplot(df, aes(x = df$area, y = df$preco)) +
  geom_point() +
  stat_smooth()


#b.1) Ajuste um modelo polinomial de segundo grau.


pm_model2 <- lm(preco ~ area + I(area^2)    , data = df)
summary(pm_model2)

rmse2<-rmse(df$preco,predict(pm_model2)) 
rmse2


#b.2) 

pm_model2 <- lm(preco ~ poly(area, 2), data = df)
summary(pm_model2)

# Make predictions
df$preco_pm2 <- predict(pm_model2, df)

# Model performance
library(caret)
RMSE = RMSE(df$preco_pm2, df$preco)
R2 = R2(df$preco_pm2, df$preco)



#c) Calcule e interprete o coeficiente de determinação.

#Interpreta��o r2: 91.13% da varia��o no pre�o das casas est� sendo explicada pela regress�o nos valores de area. 


#d) Ajuste um modelo linear simples, um modelo polinomial de grau 3, de grau 4 e de grau 10. 
#Com base nos resultados encontrados para todos os modelos ajustados, qual o modelo você indicaria? 
#Justifique sua resposta.

#d.1) Ajuste um modelo linear simples


pm_model1 <- lm(preco ~ area    , data = df)
summary(pm_model1)

rmse1<-rmse(df$preco,predict(pm_model1)) 
rmse1


#or 

pm_model1 <- lm(preco ~ area, data = df)
summary(pm_model1)

# Make predictions
df$preco_pm1 <- predict(pm_model1, df)

# Model performance
library(caret)
RMSE = RMSE(df$preco_pm1, df$preco)
R2 = R2(df$preco_pm1, df$preco)



#modelo de grau 3


pm_model3 <- lm(preco ~ area + I(area^2) + I(area^3)    , data = df)
summary(pm_model3)

rmse3<-rmse(df$preco,predict(pm_model3)) 
rmse3


#or

pm_model3 <- lm(preco ~ poly(area, 3), data = df)
summary(pm_model3)

# Make predictions
df$preco_pm3 <- predict(pm_model3, df)

# Model performance
library(caret)
RMSE = RMSE(df$preco_pm3, df$preco)
R2 = R2(df$preco_pm3, df$preco)



#modelo de grau 4


pm_model4 <- lm(preco ~ area + I(area^2) + I(area^3) + I(area^4) , data = df)
summary(pm_model4)

rmse4<-rmse(df$preco,predict(pm_model4)) 
rmse4


#or

pm_model4 <- lm(preco ~ poly(area, 5), data = df)
summary(pm_model4)

# Make predictions
df$preco_pm4 <- predict(pm_model4, df)

# Model performance
library(caret)
RMSE = RMSE(df$preco_pm4, df$preco)
R2 = R2(df$preco_pm4, df$preco)


#modelo de grau 10


pm_model10 <- lm(preco ~ area + I(area^2) + I(area^3) + I(area^4) +  I(area^5) + I(area^6) + I(area^7) + I(area^8) +  I(area^9) +  I(area^10) , data = df)
summary(pm_model10)

rmse10<-rmse(df$preco,predict(pm_model10)) 
rmse10


#or

pm_model10 <- lm(preco ~ poly(area, 10), data = df)
summary(pm_model10)

# Make predictions
df$preco_pm10 <- predict(pm_model10, df)

# Model performance
library(caret)
RMSE = RMSE(df$preco_pm10, df$preco)
R2 = R2(df$preco_pm10, df$preco)



ggplot (dados = df) +  
  geom_point(
   aes (x = df$area, y = df$preco),size = 3)+
  (aes (x = df$area, y = df$preco)) +
  (aes (x = df$area, y = df$preco)) +
  (aes (x = df$area, y = df$preco)) +   
  (aes (x = df$area, y = df$preco)) +   
  geom_line (aes (x = df$area, y = pm_model1$fit), color = "red") +
  geom_line (aes (x = df$area, y = pm_model2$fit), color = "blue")+
  geom_line (aes (x = df$area, y = pm_model3$fit), color = "green")+
  geom_line (aes (x = df$area, y = pm_model4$fit), color = "yellow")+
  geom_line (aes (x = df$area, y = pm_model10$fit), color = "black")



#Com base nos resultados encontrados para todos os modelos ajustados, qual o modelo você indicaria? Justifique sua resposta.


#1 grau: A linha reta � incapaz de capturar os padr�es nos dados.
#Subajuste (under-fitting): RMSE= 40.41 e r^2=0,669
 

#2 grau: A curva quadr�tica � capaz de ajustar os dados melhor que a linha linear
#RMSE= 20.93 e r^2=0,9113

#3 grau: A curva passa por mais pontos de dados do que os gr�ficos quadr�tico e linear.
#RMSE= 13.74 e r^2=0,9618

#4 grau: Pouca diferen�a da de grau 3.
#RMSE= 13.43 e r^2=0,9634

#Grau 10: A curva passa por mais pontos de dados. Mesmo que esse modelo passe pela maioria dos dados, ele falhar� na generaliza��o de dados n�o vistos.
#Sobreajuste (Over-fitting): RMSE=0.0000000223 e r^2=1

#Com base no �Princ�pio da parcim�nia" (modelos mais simples devem ser escolhidos aos mais complexos, desde que a qualidade do ajuste seja similar)
#o modelo de grau 3 deve ser escolhido. 


