#Quest�o 1

df <- read.table("questao1.txt", header = TRUE)

#or

#df <- read.csv('questao1.csv', sep = ',', dec = '.')

#print df 
df


RLM <- lm(receita ~ gasto_tv + gasto_jornal, data = df)
RLM

summary(RLM)

b0 <- summary(RLM)$coefficients[1]

b1 <- summary(RLM)$coefficients[2]

b2 <- summary(RLM)$coefficients[3]

#a)  equação da regressão estimada 

#y_est = b0 + b1*x1 + b2*x2   

#y_est = 83.230 + 2.290*gasto_tv + 1.301*gasto_jornal   

y_est = b0 + b1*df$gasto_tv + b2*df$gasto_jornal


#b) interprete os parâmetros de regress�o estimados acima

#Interpreta��o b0: n�o possui interpreta��o pr�tica.

#Interpreta��o b1: Mantendo os gastos com prpaganda em jornal constante, tem-se que para o aumento de 1000,00 nos gastos
#com propaganda em TV estima-se uma aumento m�dio de 2.290x1000 na receita bruta.

#Interpreta��o b2: Mantendo os gastos com prpaganda em TV constante, tem-se que para o aumento de 1000,00 nos gastos
#com propaganda em jornal estima-se uma aumento m�dio de 1.301x1000 na receita bruta.


#c) Calcule e interprete o coeficiente de determinação


#c.1) utilizando o pacote caret 
library(caret)
# (a) Prediction error, RMSE
RMSE(y_est, df$receita)
# (b) R-square
R2(y_est, df$receita)


#c.2) utilizando o pacote metrics

predict(RLM)
library(Metrics)
rmse(df$receita,predict(RLM))  
R2(df$receita,predict(RLM))


#Interpreta��o r2: 91.90% da varia��o na receita bruta da empresa est� sendo explicada 
#pela equa��o de regress�o no valores de gastos com TV e Jornal.


#d.1) 
y_est = b0 + b1*3500 + b2*1800


#d.2) 
predict(RLM, list(gasto_tv = 3.500, gasto_jornal = 1.800), interval = "conf")


#e) 
RLS <- lm(receita ~ gasto_tv, data = df)
RLS

summary(RLS)

predict(RLS)
library(Metrics)
rmse(df$receita,predict(RLS))  
R2(df$receita,predict(RLS))


b0 <- summary(RLS)$coefficients[1]

b1 <- summary(RLS)$coefficients[2]


#y_est = b0 + b1*x1 + b2*x2   

#y_est = 88.637 + 1.603*gasto_tv 

y_est = b0 + b1*df$gasto_tv 


#f) Comente sobre a qualidade do ajuste entre a equa��o estimada na letra a. e letra e. 
#   Qual delas voc� escolheria? Justifique sua resposta.

#O modelo ajustado na letra a. tem melhor qualidade de ajuste pois apresentou um aior valor de r2
#e menor RMSE.




